import React from 'react'
export default function Segments(){
  const segs = ['Infoprodutores','E-commerce','Dropshipping','Comércio','Construção Civil','Saúde','Beleza','Profissionais Liberais','Igrejas & ONGs','Imobiliário']
  return (
    <section id="segmentos" className="section container">
      <h2>Segmentos que atendemos</h2>
      <ul style={{listStyle:'none',padding:0,margin:0,display:'flex',flexWrap:'wrap',gap:10}}>
        {segs.map(x => <li key={x} style={{padding:'8px 12px',border:'1px solid #ffffff1a',borderRadius:999,background:'#0b1220d9'}}>{x}</li>)}
      </ul>
    </section>
  )
}