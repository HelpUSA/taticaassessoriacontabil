import React from 'react'
export default function FAQ(){
  return (
    <section id="faq" className="section container">
      <h2>Perguntas frequentes</h2>
      <details><summary>Terei reuniões presenciais?</summary><p>Atendemos online e presencialmente em João Pessoa (Manaíra). Agende pelo WhatsApp.</p></details>
      <details><summary>Como é a cobrança da mensalidade?</summary><p>Planos fixos conforme o porte e regime da empresa. Emitimos NFS-e e boleto.</p></details>
      <details><summary>Quais cidades atendem?</summary><p>Atendimento nacional com foco em Paraíba e região metropolitana de João Pessoa.</p></details>
      <details><summary>Quais serviços estão inclusos?</summary><p>Contábil, fiscal, trabalhista e societário básicos, além de suporte e orientação contínua.</p></details>
    </section>
  )
}