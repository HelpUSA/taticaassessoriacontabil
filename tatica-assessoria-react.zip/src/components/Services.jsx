import React from 'react'
export default function Services(){
  const items = ['Assessoria Contábil','Fiscal & Tributária','Departamento Pessoal','Societário','Planejamento Tributário','Contabilidade para MEI','E-commerce & Infoprodutores','IRPF & IRPJ']
  return (
    <section id="servicos" className="section container">
      <h2>Serviços ideais para a sua empresa</h2>
      <div className="grid cards">
        {items.map(t => <article className="card" key={t}><h3>{t}</h3><p>Atendimento completo e orientação contínua.</p></article>)}
      </div>
    </section>
  )
}