import React from 'react'
export default function Footer(){
  return (
    <footer>
      <div className="container footer-inner">
        <small>© {new Date().getFullYear()} Tática Assessoria Contábil — João Pessoa, PB</small>
        <nav className="social">
          <a href="https://wa.me/5583988419118" target="_blank" rel="noopener">WhatsApp</a>
          <a href="#" target="_blank" rel="noopener">Instagram</a>
          <a href="#" target="_blank" rel="noopener">LinkedIn</a>
        </nav>
      </div>
    </footer>
  )
}
