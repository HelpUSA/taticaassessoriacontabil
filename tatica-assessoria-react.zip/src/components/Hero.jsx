import React from 'react'
export default function Hero(){
  const wa = 'https://wa.me/5583988419118?text=' + encodeURIComponent('Olá! Gostaria de um orçamento de contabilidade.');
  return (
    <header style={{position:'relative',minHeight:'86vh',display:'grid',placeItems:'center',overflow:'hidden',textAlign:'center'}} id="hero">
      <video autoPlay muted playsInline loop style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover',filter:'brightness(.55) contrast(1.05)'}}>
        <source src="/assets/hero-video.mp4" type="video/mp4" />
      </video>
      <div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse at center,#0000 30%,#0008 70%,#000b 100%)'}} />
      <div className="container" style={{position:'relative',zIndex:2,padding:'56px 0'}}>
        <img src="/assets/marx01.png" alt="Representante Tática" style={{width:'min(220px,36vw)',borderRadius:'999px',border:'4px solid #ffffff40',boxShadow:'0 20px 60px #000b',background:'#fff',marginBottom:12}} loading="lazy" />
        <h1 style={{fontSize:'clamp(28px,5vw,44px)',margin:'8px 0 6px'}}>Tática Assessoria Contábil</h1>
        <p style={{color:'#cbd5e1',fontSize:'clamp(14px,2.2vw,18px)'}}>💎 11 anos de experiência • 🏆 Planejamento tributário para pagar menos, com segurança.</p>
        <div style={{marginTop:16,display:'flex',gap:12,justifyContent:'center',flexWrap:'wrap'}}>
          <a className="btn primary" href="#servicos">Ver serviços</a>
          <a className="btn ghost" href={wa} target="_blank" rel="noopener">Falar no WhatsApp</a>
        </div>
      </div>
    </header>
  )
}
