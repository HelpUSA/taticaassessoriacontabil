import React from 'react'
export default function Benefits(){
  const wa = 'https://wa.me/5583988419118?text=' + encodeURIComponent('Quero abrir minha empresa.');
  return (
    <section id="beneficios" className="section container" style={{display:'grid',gridTemplateColumns:'1.2fr .8fr',gap:24}}>
      <div>
        <h2>Vantagens e benefícios</h2>
        <ul style={{paddingLeft:18}}>
          <li>Relatórios mensais claros para decisão</li>
          <li>Softwares para troca segura de documentos</li>
          <li>Atendimento multicanal e suporte próximo</li>
          <li>Gestão completa das rotinas contábeis</li>
        </ul>
        <a className="btn ghost" href="#faq">Perguntas frequentes</a>
      </div>
      <div className="card">
        <h3>Abra sua empresa sem burocracia</h3>
        <p>Preencha um formulário e cuidamos do restante. Você acompanha cada etapa.</p>
        <a className="btn primary" href={wa} target="_blank" rel="noopener">Quero abrir</a>
      </div>
    </section>
  )
}