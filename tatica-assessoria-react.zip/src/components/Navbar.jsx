import React from 'react'
export default function Navbar(){
  return (
    <nav className="container" style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'14px 0'}}>
      <strong>Tática Assessoria Contábil</strong>
      <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
        <a href="#servicos">Serviços</a>
        <a href="#segmentos">Segmentos</a>
        <a href="#faq">FAQ</a>
        <a href="#contato">Contato</a>
      </div>
    </nav>
  )
}
