import React from 'react'
import Navbar from '../components/Navbar'
import Hero from '../components/Hero'
import Services from '../components/Services'
import Segments from '../components/Segments'
import Benefits from '../components/Benefits'
import FAQ from '../components/FAQ'
import Contact from '../components/Contact'
import Footer from '../components/Footer'
import WhatsAppFloat from '../components/WhatsAppFloat'

export default function App(){
  return (
    <>
      <Navbar />
      <Hero />
      <section className="strip">
        <div className="container strip-inner">
          <div>📍 Avenida João Câncio, 620 — Sala 901 — Manaíra, João Pessoa - PB</div>
          <div>⏰ Seg–Sex 08h–18h</div>
          <div>☎️ <a href="tel:+5583988419118">+55 83 98841-9118</a></div>
        </div>
      </section>
      <Services />
      <Segments />
      <Benefits />
      <FAQ />
      <Contact />
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
