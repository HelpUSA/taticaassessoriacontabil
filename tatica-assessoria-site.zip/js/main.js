// main.js — interações básicas
const y = document.getElementById('year'); if (y) y.textContent = new Date().getFullYear();

function sendForm(e){
  e.preventDefault();
  const fd = new FormData(e.target);
  const data = Object.fromEntries(fd.entries());
  // Simples envio via mailto (substituir por backend/Nhost/Railway quando desejar)
  const subject = encodeURIComponent('Contato via site — Tática Assessoria Contábil');
  const body = encodeURIComponent(`Nome: ${data.nome}\nE-mail: ${data.email}\nMensagem: ${data.mensagem}`);
  const href = `mailto:contato@taticaassessoria.com.br?subject=${subject}&body=${body}`;
  window.location.href = href;
  const s = document.getElementById('formStatus');
  if (s) s.textContent = 'Abrindo seu aplicativo de e-mail…';
  return false;
}
